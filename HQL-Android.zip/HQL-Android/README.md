# HQL – Android app

Your HQL website wrapped in a native Android app. The site is bundled inside the app,
so it opens instantly; data still comes from your Supabase project as before.

## Get the APK (about 5 minutes)

1. Create a new repository on GitHub and upload everything from this folder, including the
   hidden `.github` folder. If `.github` is skipped by the uploader, use *Add file → Create new file*,
   name it `.github/workflows/build-apk.yml` and paste the contents of that file from the zip.
2. Open the **Actions** tab → **Build APK**. It starts by itself after the upload
   (otherwise click *Run workflow*). It takes 3–5 minutes.
3. Open the finished run → **Artifacts** → click **HQL.apk** (it downloads as a normal APK, no unzipping).
4. Copy it to the phone and open it. Android may ask you to allow installing from this source.

Tip: push a tag such as `v1.0` and the APK is also attached to a GitHub **Release** – a clean
download link you can share.

## Updating

- **Website changed?** Replace the files in `app/src/main/assets/`, commit, and a new APK is built.
  It installs over the old one (same signing key, version number goes up on every build).
- **Don't want a new APK for every website change?** *Actions → Build APK → Run workflow* and enter your
  live address (`https://…`). That build always shows the live site. (Or set `siteUrl=` in `gradle.properties`.)

## Good to know

- Needs Android 8.0+ and an up-to-date *Android System WebView*.
- Location permission is requested the first time the run page needs GPS. As in a browser, GPS
  fixes pause while the screen is off or the app is in the background.
- GPX and report images are saved to **Downloads/HQL**.
- Something works on the website but not in the app (empty map, run not saving)? The app's pages are served
  from `https://appassets.androidplatform.net`. Allow that address in your Mapbox token's URL restrictions
  and in the CORS settings of your Supabase functions – or use the live-address build described above.
- `app/hql.keystore` (password `hqlandroid`) is included so every build has the same signature.
  If you ever publish on Google Play, create your own key instead.
- Package name is `com.hql.app` (`app/build.gradle`). Changing it later makes Android treat it as a different app.
