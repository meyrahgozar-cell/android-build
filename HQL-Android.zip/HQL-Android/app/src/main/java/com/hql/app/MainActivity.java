package com.hql.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.MimeTypeMap;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * The whole app: one full-screen WebView that shows the HQL website.
 *
 * The website files live in assets/ and are served from a virtual https address, so the
 * pages behave exactly like on a real https site (localStorage, GPS, etc. all work).
 */
public class MainActivity extends ComponentActivity {

    /** Virtual https address the bundled website is served from. */
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String DEFAULT_BG = "#05060a";

    private SharedPreferences prefs;
    private WebViewAssetLoader assetLoader;
    private FrameLayout root;
    private WebView webView;
    private int themeColor = Color.parseColor(DEFAULT_BG);
    private String startUrl;
    private String liveHost;            // null while the bundled copy of the site is used
    private String bridgeJs = "";
    private String offlineHtml = "";

    // requests coming from the page that wait for an Android screen / permission dialog
    private ValueCallback<Uri[]> fileCallback;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;

    private final ActivityResultLauncher<Intent> fileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                ValueCallback<Uri[]> cb = fileCallback;
                fileCallback = null;
                if (cb != null) {
                    cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(
                            result.getResultCode(), result.getData()));
                }
            });

    private final ActivityResultLauncher<String[]> locationLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(), grants -> {
                boolean fine = Boolean.TRUE.equals(grants.get(Manifest.permission.ACCESS_FINE_LOCATION));
                boolean coarse = Boolean.TRUE.equals(grants.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                GeolocationPermissions.Callback cb = geoCallback;
                String origin = geoOrigin;
                geoCallback = null;
                geoOrigin = null;
                if (cb != null) cb.invoke(origin, fine || coarse, false);
                if (!fine && !coarse) {
                    toast(getString(R.string.location_denied));
                } else if (!fine) {
                    toast(getString(R.string.location_approximate));
                }
            });

    // ------------------------------------------------------------------ lifecycle

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("hql", MODE_PRIVATE);

        // Which site to show: the bundled copy (default) or a live https address (-PsiteUrl).
        String live = BuildConfig.SITE_URL.trim();
        Uri liveUri = live.isEmpty() ? null : Uri.parse(live);
        if (liveUri != null && "https".equalsIgnoreCase(liveUri.getScheme()) && liveUri.getHost() != null) {
            startUrl = live;
            liveHost = liveUri.getHost();
        } else {
            startUrl = "https://" + ASSET_HOST + "/index.html";
        }

        // Draw behind the system bars; the insets listener below keeps the page clear of them.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(ASSET_HOST)
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        bridgeJs = readRaw(R.raw.hql_bridge);
        offlineHtml = readRaw(R.raw.offline);

        root = new FrameLayout(this);
        root.setBackgroundColor(themeColor);
        setContentView(root);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, ime.bottom));
            return WindowInsetsCompat.CONSUMED;
        });

        webView = createWebView();
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    moveTaskToBack(true);
                }
            }
        });

        // After the system recreated the app (e.g. low memory) come back to the same page.
        WebBackForwardList restored = null;
        if (savedInstanceState != null) restored = webView.restoreState(savedInstanceState);
        if (restored == null) loadStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        try {
            webView.saveState(outState);
        } catch (RuntimeException ignored) {
            // nothing to save if the web process is gone
        }
    }

    @Override
    protected void onDestroy() {
        if (fileCallback != null) {
            fileCallback.onReceiveValue(null);
            fileCallback = null;
        }
        root.removeAllViews();
        webView.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ WebView

    private void loadStart() {
        webView.loadUrl(startUrl);
    }

    private WebView createWebView() {
        WebView wv = new WebView(this);
        wv.setBackgroundColor(themeColor);

        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage / sessionStorage (login, run drafts)
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " HQLApp/" + BuildConfig.VERSION_NAME);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        wv.addJavascriptInterface(new Bridge(), "HQLNative");
        wv.setWebViewClient(new HqlClient());
        wv.setWebChromeClient(new HqlChrome());
        wv.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                // normally handled by hql_bridge.js; this is the fallback
                wv.evaluateJavascript("window.__hqlSave&&window.__hqlSave(" + jsString(url) + ",'')", null);
            } else {
                openExternal(Uri.parse(url));
            }
        });
        return wv;
    }

    private class HqlClient extends WebViewClient {

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            return assetLoader.shouldInterceptRequest(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleNavigation(request.getUrl());
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            // repaint the system bars right away with the colour this page used last time
            String saved = prefs.getString("tc:" + pathOf(url), null);
            if (saved != null) applyThemeColor(saved);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (!bridgeJs.isEmpty()) view.evaluateJavascript(bridgeJs, null);
            final String path = pathOf(url);
            view.evaluateJavascript(
                    "(function(){var m=document.querySelector('meta[name=\"theme-color\"]');return m?m.content:'';})()",
                    value -> {
                        String css = unquote(value);
                        if (css.startsWith("#") && applyThemeColor(css) && !path.isEmpty()) {
                            prefs.edit().putString("tc:" + path, css).apply();
                        }
                    });
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            // only the live-site mode needs the network to show a page
            if (liveHost != null && request.isForMainFrame()) {
                view.loadDataWithBaseURL(null, offlineHtml, "text/html", "utf-8", null);
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // the web process crashed or was killed: swap in a fresh WebView instead of crashing
            root.removeView(webView);
            webView.destroy();
            webView = createWebView();
            root.addView(webView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            loadStart();
            return true;
        }
    }

    private class HqlChrome extends WebChromeClient {

        // GPS for the run page
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            if (hasLocationPermission()) {
                callback.invoke(origin, true, false);
                return;
            }
            if (geoCallback != null) geoCallback.invoke(geoOrigin, false, false);
            geoCallback = callback;
            geoOrigin = origin;
            locationLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        }

        // <input type="file"> (screenshot upload)
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                fileLauncher.launch(params.createIntent());
            } catch (ActivityNotFoundException e) {
                fileCallback = null;
                callback.onReceiveValue(null);
            }
            return true;
        }

        // alert / confirm / prompt shown as plain dialogs (no address in the title)
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            if (isFinishing()) {
                result.confirm();
                return true;
            }
            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok, (d, which) -> result.confirm())
                    .setOnCancelListener(d -> result.confirm())
                    .create();
            dialog.show();
            makeRtl(dialog);
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            if (isFinishing()) {
                result.cancel();
                return true;
            }
            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setPositiveButton(R.string.ok, (d, which) -> result.confirm())
                    .setNegativeButton(R.string.cancel, (d, which) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .create();
            dialog.show();
            makeRtl(dialog);
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String defaultValue,
                                  JsPromptResult result) {
            if (isFinishing()) {
                result.cancel();
                return true;
            }
            EditText input = new EditText(MainActivity.this);
            input.setText(defaultValue == null ? "" : defaultValue);
            input.setSingleLine(false);
            input.setMaxLines(6);
            input.setGravity(Gravity.TOP | Gravity.START);
            input.setSelection(input.getText().length());
            FrameLayout box = new FrameLayout(MainActivity.this);
            box.setPadding(dp(20), dp(8), dp(20), 0);
            box.addView(input, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                    .setMessage(message)
                    .setView(box)
                    .setPositiveButton(R.string.ok, (d, which) -> result.confirm(input.getText().toString()))
                    .setNegativeButton(R.string.cancel, (d, which) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel())
                    .create();
            if (dialog.getWindow() != null) {
                dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
            }
            dialog.show();
            makeRtl(dialog);
            input.requestFocus();
            return true;
        }
    }

    /** Methods the page can call as window.HQLNative.* (used by hql_bridge.js and offline.html). */
    private class Bridge {

        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
                String where = saveToDownloads(cleanFileName(name, type), type, data);
                String message = getString(R.string.file_saved, where);
                runOnUiThread(() -> toast(message));
            } catch (Exception e) {
                runOnUiThread(() -> toast(getString(R.string.file_save_failed)));
            }
        }

        @JavascriptInterface
        public void saveFailed() {
            runOnUiThread(() -> toast(getString(R.string.file_save_failed)));
        }

        @JavascriptInterface
        public void retry() {
            runOnUiThread(MainActivity.this::loadStart);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Keep the site inside the app; hand everything else (phone numbers, other sites) to Android. */
    private boolean handleNavigation(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        switch (scheme) {
            case "":
            case "about":
            case "blob":
            case "data":
            case "javascript":
                return false;
            case "http":
            case "https":
                String host = uri.getHost();
                if (host != null && (host.equalsIgnoreCase(ASSET_HOST) || host.equalsIgnoreCase(liveHost))) {
                    return false;
                }
                openExternal(uri);
                return true;
            case "tel":
                startSafely(new Intent(Intent.ACTION_DIAL, uri));
                return true;
            case "mailto":
            case "sms":
            case "smsto":
            case "geo":
                startSafely(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            default:
                return true;
        }
    }

    private void openExternal(Uri uri) {
        startSafely(new Intent(Intent.ACTION_VIEW, uri));
    }

    private void startSafely(Intent intent) {
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException ignored) {
            // no app can handle it
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Colours the system bars and the area behind the page like the page's theme-color. */
    private boolean applyThemeColor(String css) {
        int color;
        try {
            color = Color.parseColor(css.trim());
        } catch (IllegalArgumentException e) {
            return false;
        }
        color = color | 0xFF000000;
        themeColor = color;
        root.setBackgroundColor(color);
        webView.setBackgroundColor(color);
        boolean lightBackground = ColorUtils.calculateLuminance(color) > 0.5;
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.setAppearanceLightStatusBars(lightBackground);
        controller.setAppearanceLightNavigationBars(lightBackground);
        return true;
    }

    /** Saves into Downloads/HQL (no permission needed on Android 10+). Returns a folder label. */
    private String saveToDownloads(String fileName, String mime, byte[] data) throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HQL");
            values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("Could not create the file");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IOException("Could not open the file");
                out.write(data);
            } catch (IOException e) {
                resolver.delete(uri, null, null);
                throw e;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
            return "Downloads/HQL";
        }
        // Android 8-9: app folder on shared storage (needs no permission)
        File base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (base == null) throw new IOException("No storage available");
        File dir = new File(base, "HQL");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Could not create the folder");
        try (FileOutputStream out = new FileOutputStream(new File(dir, fileName))) {
            out.write(data);
        }
        return "Android/data/" + getPackageName() + "/files/Download/HQL";
    }

    private static String cleanFileName(String raw, String mime) {
        String name = raw == null ? "" : raw.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        if (name.isEmpty()) name = "hql-file";
        if (name.length() > 120) name = name.substring(0, 120);
        if (name.indexOf('.') < 0) {
            String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
            if (ext != null) name = name + "." + ext;
        }
        return name;
    }

    private String readRaw(int resId) {
        try (InputStream in = getResources().openRawResource(resId);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    private static String pathOf(String url) {
        if (url == null) return "";
        String path = Uri.parse(url).getPath();
        return path == null ? "" : path;
    }

    /** evaluateJavascript() hands back JSON, so a string comes wrapped in quotes. */
    private static String unquote(String value) {
        if (value == null) return "";
        String v = value.trim();
        if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
        return v.equals("null") ? "" : v;
    }

    private static String jsString(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "") + "\"";
    }

    private void makeRtl(AlertDialog dialog) {
        if (dialog.getWindow() != null) {
            dialog.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
