/*
 * Injected into every page by the Android app (after the page has loaded).
 * A WebView ignores <a download> links that point to blob:/data: URLs, which is how the
 * site exports GPX files and report images. This hands those files to the app so it can
 * save them into the Downloads folder.
 */
(function () {
  if (window.__hqlNativeReady || !window.HQLNative) return;
  window.__hqlNativeReady = true;

  function toBase64(blob, done) {
    var reader = new FileReader();
    reader.onloadend = function () {
      var text = String(reader.result || '');
      done(text.slice(text.indexOf(',') + 1));
    };
    reader.onerror = function () { done(null); };
    reader.readAsDataURL(blob);
  }

  function save(url, name) {
    fetch(url)
      .then(function (res) { return res.blob(); })
      .then(function (blob) {
        toBase64(blob, function (b64) {
          if (b64 === null) { window.HQLNative.saveFailed(); return; }
          window.HQLNative.saveFile(name || 'file', blob.type || '', b64);
        });
      })
      .catch(function () { window.HQLNative.saveFailed(); });
  }
  window.__hqlSave = save;

  function isSavable(a) {
    return !!a && a.hasAttribute && a.hasAttribute('download') && /^(blob|data):/i.test(a.href || '');
  }

  // anchors that are never added to the page: a = document.createElement('a'); a.click()
  var originalClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (isSavable(this)) { save(this.href, this.getAttribute('download')); return; }
    return originalClick.apply(this, arguments);
  };

  // anchors that are part of the page
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (isSavable(a)) { e.preventDefault(); save(a.href, a.getAttribute('download')); }
  }, true);
})();
